extreme_startup_servers
=======================

Extreme Startup skeleton server implementations in various frameworks and languages.

The server can be cloned from https://github.com/jhannes/extreme_startup.git
