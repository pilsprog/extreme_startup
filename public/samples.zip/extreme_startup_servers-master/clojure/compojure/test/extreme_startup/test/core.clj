(ns extreme-startup.test.core
  (:use [extreme-startup.core])
  (:use [clojure.test]))

(deftest replace-me ;; FIXME: write
  (is false "No tests have been written."))
