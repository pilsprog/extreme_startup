(defproject extreme-startup "0.1.0-SNAPSHOT"
            :description "Extreme Startup participant for Clojure"
            :dependencies [[org.clojure/clojure "1.3.0"]
                           [noir "1.2.0"]]
            :main extremestartup.server)

