Welcome
=======
This is a solution for the Extreme Startup Workshop. It is a solution based on Nancy (http://www.nancyfx.org/).


Getting started
---------------
* Install NuGet (from http://nuget.org/)
* Open the Solution in Visual Studio 2010
* To get Nancy
  * Go to Tool | Library Package Manager | Package Manager Console
  * Run: Install-Package Nancy.Hosting.Self
* Run the program!


-- Håkon K. Olafsen 2011

  