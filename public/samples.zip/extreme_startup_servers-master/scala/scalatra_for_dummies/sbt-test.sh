java -Xmx512M -jar `dirname $0`/sbt-launch.jar ~test
