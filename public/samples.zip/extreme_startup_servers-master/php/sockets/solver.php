<?
function solve($input) { 
return $input;
}
?> 
